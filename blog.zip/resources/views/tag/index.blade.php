<x-master>
    <x-tag-edit :tags="$tags"/>
</x-master>
