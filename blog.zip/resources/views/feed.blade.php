<x-master>
    <div class="heading-page">
    <section class="blog-posts">
        <div class="container">
            <div class="row">
                @include('components.timeline')
                @include('components._sidebar-links')
            </div>
        </div>
    </section>
    </div>
</x-master>
