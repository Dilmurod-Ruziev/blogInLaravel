@component('mail::message')
    # {{$subject}}

    My name is {{$name}}

    {{$msg}}
@endcomponent


