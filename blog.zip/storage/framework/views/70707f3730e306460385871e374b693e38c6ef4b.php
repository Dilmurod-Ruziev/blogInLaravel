 <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.master','data' => []]); ?>
<?php $component->withName('master'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="heading-page">
        <section class="blog-posts">
            <div class="container">
                <div class="row">
                    <div class="col-lg-8">
                        <div class="all-blog-posts">
                            <div class="row">
                                <?php $__currentLoopData = $profiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-lg-12">
                                        <div class="blog-post">
                                            <div class="down-content">
                                                <img src="<?php echo e($profile->getAvatar()); ?>" alt="img" width="50" height="50">
                                                <a href="/profiles/<?php echo e($profile->id); ?>"><h4><?php echo e($profile->name); ?></h4></a>
                                                <span><?php echo e('@'.$profile->username); ?></span>
                                                <?php if($profile->description): ?>
                                                    <p><?php echo e($profile->description); ?></p>
                                                <?php else: ?>
                                                    <p class="text-secondary">Nothing here...</p>
                                                <?php endif; ?>
                                                <ul class="post-info">
                                                    <li>
                                                        <a href="<?php echo e(route('profile',$profile->id)); ?>"><?php echo e($profile->name); ?></a>
                                                    </li>
                                                    <li>
                                                        <a href="#"><?php echo e('Joined '.$profile->created_at->format('j F Y')); ?></a>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($profiles->links()); ?>

                            </div>
                        </div>
                    </div>
                    <?php echo $__env->make('components._sidebar-links', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
        </section>
    </div>
 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 



<?php /**PATH C:\xampp\htdocs\blog\blog\resources\views/profiles/index.blade.php ENDPATH**/ ?>