<?php if(current_user() == $article->user): ?>
    <div class="d-flex">
        <a href="/articles/<?php echo e($article->id); ?>/edit" class="nav-link text-secondary"><i class="far fa-edit">Edit</i></a>
        <form
            onclick="return confirm('Do you want to delete this article?');"
            action="/articles/<?php echo e($article->id); ?>"
            method="post">

            <?php echo csrf_field(); ?>
            <?php echo method_field('delete'); ?>
            <button type="submit" value="Delete"
                    class="btn bg-danger btn-sm  nav-link text-white"><i class="far fa-trash-alt"></i>
            </button>
        </form>
    </div>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\blog\blog\resources\views/components/edit-delete.blade.php ENDPATH**/ ?>