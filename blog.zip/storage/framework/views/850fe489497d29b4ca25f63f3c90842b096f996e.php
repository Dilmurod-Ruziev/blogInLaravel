<form action="/articles/<?php echo e($article->id); ?>/like"
      method="POST" id="likeButton">
    <?php echo csrf_field(); ?>
    <li class="nav-item"><i
            class="text-danger fa<?php echo e($article->isLikedBy(current_user()) ? 's' : 'r'); ?> fa-heart">

            <?php if(count($article->likes)>0): ?>
                <?php echo e(count($article->likes)); ?>

            <?php endif; ?>

        </i></li>
</form>


<?php /**PATH C:\xampp\htdocs\blog\blog\resources\views/components/like-buttons.blade.php ENDPATH**/ ?>