<?php $__env->startSection('content'); ?>
    <div class="main-banner header-text">
        <div class="container-fluid">
            <div class="owl-banner owl-carousel">
                <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="item">
                        <img src="images/banner-item-0<?php echo e(($article->id)%6+1); ?>.jpg" alt="photo">
                        <div class="item-content">
                            <div class="main-content">
                                <div class="meta-category">
                                    <span><?php echo e($article->category); ?></span>
                                </div>
                                <a href="/articles/<?php echo e($article->id); ?>"><h4><?php echo e($article->title); ?></h4></a>
                                <ul class="post-info">
                                    <li><a href="#"><?php echo e($article->user->name); ?></a></li>
                                    <li><a href="#"><?php echo e($article->created_at); ?></a></li>
                                    <li><a href="#">12 Comments</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>


    <section class="blog-posts">
        <div class="container">
            <div class="row">
                <div class="col-lg-8">
                    <div class="all-blog-posts">
                        <div class="row">
                            <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-lg-12">
                                    <div class="blog-post">
                                        <div class="blog-thumb">
                                            <img src="images/blog-post-0<?php echo e(($article->id)%3+1); ?>.jpg" alt="">
                                        </div>
                                        <div class="down-content">
                                            <span><?php echo e($article->category); ?></span>
                                            <a href="/articles/<?php echo e($article->id); ?>"><h4><?php echo e($article->title); ?></h4></a>
                                            <ul class="post-info">
                                                <li><a href="#"><?php echo e($article->user->name); ?></a></li>
                                                <li><a href="#"><?php echo e($article->created_at); ?></a></li>
                                                <li><a href="#">12 Comments</a></li>
                                            </ul>
                                            <p><?php echo e($article->body); ?></p>
                                            <div class="post-options">
                                                <div class="row">
                                                    <div class="col-6">
                                                        <ul class="post-tags">
                                                            <li><i class="fa fa-tags"></i></li>
                                                            <?php $__currentLoopData = $article->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <li><a href="/tag/<?php echo e($tag->id); ?>"><?php echo e($tag->name); ?></a>,</li>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            <li>
                                                                <div><a href="/articles/<?php echo e($article->id); ?>/edit"
                                                                        class="btn btn-warning text-dark">
                                                                        Edit
                                                                    </a></div>
                                                            </li>
                                                            <li>
                                                                <div>
                                                                    <form
                                                                        onclick="return confirm('Do you want to delete this article?');"
                                                                        action="/articles/<?php echo e($article->id); ?>"
                                                                        method="post">
                                                                        <?php echo csrf_field(); ?>
                                                                        <?php echo method_field('delete'); ?>
                                                                        <button type="submit" value="Delete"
                                                                                class="btn btn-danger btn-block">Delete
                                                                        </button>
                                                                    </form>
                                                                </div>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                    <div class="col-6">
                                                        <ul class="post-share">
                                                            <li><i class="fa fa-share-alt"></i></li>
                                                            <li><a href="#">Facebook</a>,</li>
                                                            <li><a href="#"> Twitter</a></li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php echo e($articles->links()); ?>

                        </div>
                    </div>
                </div>
            </div>
            <?php echo $__env->make('components._sidebar-links', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>

    </section>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blog\blog\resources\views/category/index.blade.php ENDPATH**/ ?>