<?php if(current_user()->isNot($user)): ?>
    <div class="d-flex flex-row">
        <form method="POST" action="/profiles/<?php echo e($user->id); ?>/follow">
            <?php echo csrf_field(); ?>
            <button type="submit"
                    class="btn btn-outline-primary mx-1"><?php echo e(current_user()->isFollowing($user)?'Unsubscribe':'Subscribe'); ?></button>
        </form>
    </div>
<?php else: ?>
    <a href="/profiles/<?php echo e($user->id); ?>/edit" class="text-dark"><i class="fas fa-2x fa-user-edit my-3 mx-1">Edit</i></a>
<?php endif; ?>



<?php /**PATH C:\xampp\htdocs\blog\blog\resources\views/components/follow-button.blade.php ENDPATH**/ ?>