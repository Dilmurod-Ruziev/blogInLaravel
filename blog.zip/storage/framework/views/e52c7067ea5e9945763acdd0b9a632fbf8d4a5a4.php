
<div class="main-banner header-text">
    <div class="container-fluid">
        <div class="owl-banner owl-carousel">
            <?php $__currentLoopData = $allArticles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(count($article->likes)>0): ?>
                <div class="item">
                    <img src="<?php echo e($article->getPhoto()); ?>" alt="photo">
                    <div class="item-content">
                        <div class="main-content">
                            <div class="meta-category">
                                <a href="/articles/<?php echo e($article->id); ?>"><h4><?php echo e($article->title); ?></h4></a>
                                <span><?php echo e($article->subheading); ?></span>
                            </div>
                            <ul class="post-info">
                                <li class="text-white"><a href="<?php echo e($article->user->id); ?>"><?php echo e($article->user->name); ?></a></li>
                                <li class="text-white"><?php echo e($article->created_at); ?></li>
                                <li class="text-white"><?php echo e(read_time($article->body)); ?></li>
                                <?php echo $__env->make('components.like-buttons', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </ul>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\blog\blog\resources\views/components/_carousel-headliner.blade.php ENDPATH**/ ?>