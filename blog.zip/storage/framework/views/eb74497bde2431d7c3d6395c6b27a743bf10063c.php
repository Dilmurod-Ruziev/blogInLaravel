 <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.master','data' => []]); ?>
<?php $component->withName('master'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="heading-page">
        <section class="blog-posts grid-system">
            <div class="container">
                <div class="row">
                    <div class="col-lg-8">
                        <div class="card border-light">
                            <div class="d-flex">
                            <a href="/articles/<?php echo e($article->id); ?>"><h2
                                    class="card-title text-dark"><?php echo e($article->title); ?></h2></a>
                            <?php echo $__env->make('components.edit-delete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>
                            <img class="card-img" src="<?php echo e($article->getPhoto()); ?>" alt="article-img"
                                 width="200">
                            <div class="card-header border-light">
                                <img src="<?php echo e($article->user->getAvatar()); ?>" alt="img" class="rounded-circle" height="30"
                                     width="30">
                                <a href="<?php echo e(route('profile',$article->user->id)); ?>"
                                   class="text-dark">  <?php echo e($article->user->name); ?></a>
                            </div>
                            <div class="card-body">
                                <p class="font-weight-bold"><?php echo e($article->subheading); ?></p>
                                <p><?php echo e($article->body); ?></p>
                            </div>
                            <ul class="nav nav-pills card-header-pills mx-1">
                                <li class="nav-item"><a href="#"
                                                        class="nav-link disabled"><?php echo e($article->created_at->format('H:m, j F')); ?></a>
                                </li>
                                <li class="nav-item"><a href="#"
                                                        class="nav-link disabled"><?php echo e(read_time($article->body)); ?></a>
                                </li>
                                <?php $__currentLoopData = $article->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="nav-item"><a href="/tag/<?php echo e($tag->id); ?>" class="nav-link"><?php echo e($tag->name); ?></a>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <br>
                        <br>
                        
                    </div>
                    <?php echo $__env->make('components._sidebar-links', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
        </section>
    </div>
 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
<?php /**PATH C:\xampp\htdocs\blog\blog\resources\views/articles/show.blade.php ENDPATH**/ ?>