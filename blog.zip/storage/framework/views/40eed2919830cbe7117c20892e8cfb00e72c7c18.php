<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\blog\blog\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>