<div class="col-lg-8">
    <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card border-light">
            <img class="card-img-top" src="<?php echo e($article->photo); ?>" alt="article-img"
                 width="200">
            <div class="card-header border-light">
                <img src="<?php echo e($article->user->getAvatar()); ?>" alt="img" class="rounded-circle" height="30"
                     width="30">
                <a href="<?php echo e(route('profile',$article->user->id)); ?>" class="text-dark">  <?php echo e($article->user->name); ?></a>
            </div>
            <div class="card-body">
                <a href="/articles/<?php echo e($article->id); ?>"><h2 class="card-title text-dark"><?php echo e($article->title); ?></h2></a>
                <p ><?php echo e($article->subheading); ?></p>
            </div>
                <ul class="nav nav-pills card-header-pills mx-1">
                    <li class="nav-item"><a href="#" class="nav-link disabled"><?php echo e($article->created_at->format('H:m, j F')); ?></a>
                    </li>
                    <li class="nav-item"><a href="#" class="nav-link disabled"><?php echo e(read_time($article->body)); ?></a></li>
                    <li class="nav-item"><a href="#" class="nav-link text-danger"><i
                                class="far fa-heart"></i><?php echo e($article->likes ?: 0); ?></a>
                    </li>





                </ul>
        </div>
        <br>
        <br>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>

<?php /**PATH C:\xampp\htdocs\blog\blog\resources\views/components/timeline.blade.php ENDPATH**/ ?>
