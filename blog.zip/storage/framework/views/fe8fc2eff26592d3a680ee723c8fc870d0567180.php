<section class="contact-us">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="down-contact">
                    <div class="row">
                        <div class="col-lg-8">
                            <div class="sidebar-item contact-form">
                                <div class="sidebar-heading">
                                    <h2>Send us a message</h2>
                                </div>
                                <div class="row">
                                    <div class="col-lg-12 my-2">
                                        <h2>Tag Clouds</h2>
                                        <br>
                                        <table class="table table-active table-light">
                                            <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <th scope="row"><a href="/tag/<?php echo e($tag->id); ?>"><?php echo e($tag->name); ?></a></th>
                                                    <td><a href="/tag/<?php echo e($tag->id); ?>/edit"
                                                           class="btn btn-warning text-dark">
                                                            Edit
                                                        </a></td>
                                                    <td>
                                                        <form
                                                            onclick="return confirm('Do you want to delete this tag?');"
                                                            action="/tag/<?php echo e($tag->id); ?>"
                                                            method="post">

                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('delete'); ?>
                                                            <button type="submit" value="Delete"
                                                                    class="btn bg-danger btn-sm">Delete
                                                            </button>
                                                        </form>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </table>
                                        <div><a href="/tag/create"
                                                class="btn btn-success">
                                                Create
                                            </a></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php /**PATH C:\xampp\htdocs\blog\blog\resources\views/components/tag-edit.blade.php ENDPATH**/ ?>