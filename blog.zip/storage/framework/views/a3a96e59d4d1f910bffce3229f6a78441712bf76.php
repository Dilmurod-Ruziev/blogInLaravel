 <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.master','data' => []]); ?>
<?php $component->withName('master'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <?php if($tag->articles->count()>0): ?>
        <div class="heading-page">
            <section class="blog-posts">
                <div class="container">
                    <h2><?php echo e($tag->name); ?></h2>
                    <br>
                    <div class="row">
                        <?php echo $__env->make('components.timeline', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php echo $__env->make('components._sidebar-links', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                </div>
            </section>
        </div>
    <?php else: ?>
        <div class="heading-page">
            <section class="blog-posts">
                <h1 class="text-info">There is no articles yet :(</h1>
                <br>
                <a href="/tag" class="d-flex"><i class="fas fa-arrow-left fa-2x d-flex text-dark"><h3 class="d-flex mx-1"> Tags</h3></i></a>
            </section>
        </div>
    <?php endif; ?>

 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

<?php /**PATH C:\xampp\htdocs\blog\blog\resources\views/tag/show.blade.php ENDPATH**/ ?>