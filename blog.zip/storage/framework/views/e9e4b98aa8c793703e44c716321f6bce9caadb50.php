<div class="col-lg-4">
    <div class="sidebar">
        <div class="row">
            <div class="col-lg-12">
                <div class="sidebar-item categories">
                    <div class="sidebar-heading">
                        <a href="/profiles"><h2>Friends</h2></a>
                    </div>
                    <div class="content">
                        <ul>
                            <?php $__currentLoopData = auth()->user()->follows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                
                                <li><a href="/profiles/<?php echo e($user->id); ?>">- <?php echo e($user->name); ?></a>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="/profiles"> >> All Users <<</a>
                                </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-lg-12">
                <div class="sidebar-item tags">
                    <div class="sidebar-heading">
                        <a href="/tag"><h2>Tags</h2></a>
                    </div>
                    <div class="content">
                        <ul>
                            <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="/tag/<?php echo e($tag->id); ?>"><?php echo e($tag->name); ?></a></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <li><a href="/tag/create">+</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>










<?php /**PATH C:\xampp\htdocs\blog\blog\resources\views/components/_sidebar-links.blade.php ENDPATH**/ ?>